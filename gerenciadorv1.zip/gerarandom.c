#include <stdio.h>
#include <stdlib.h>

int main(){

	FILE *fptr;
	int i;
	
	fptr = fopen("anomaly500000.dat","w");
	
	if(fptr == NULL)
   	{
      		printf("Error!\n\n");   
      		exit(1);             
   	}
   	
   	fprintf(fptr, "50000 1000\n");
   	
   	  for (i = 0; i < 500000; i++){
   	  /* gerando valores aleatórios entre zero e 100 */
    	  	fprintf(fptr, "%d w\n", rand() % 50000);
  }
  
  	fclose(fptr);
	
}
